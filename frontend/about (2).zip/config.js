window.API_BASE_URL = window.API_BASE_URL || "http://localhost:10000";
